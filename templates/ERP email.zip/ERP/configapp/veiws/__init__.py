from .view_student import *
from .view_teacher import *
from .view_register import *
from .view_group import *