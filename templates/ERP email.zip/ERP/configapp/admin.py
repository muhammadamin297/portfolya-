from django.contrib import admin
from configapp.models import *
admin.site.register(Teacher)
admin.site.register(Student)
admin.site.register(User)